#!/bin/bash
# Expo CLI 便捷脚本
# 用法: ./scripts/expo-cli.sh <command>
# 例如: ./scripts/expo-cli.sh "eas build --platform android --profile preview"

# 加载 Token
source /workspace/projects/.env.expo
export EXPO_TOKEN

cd /workspace/projects/client

# 执行命令
echo "执行: $@"
eval "$@"
