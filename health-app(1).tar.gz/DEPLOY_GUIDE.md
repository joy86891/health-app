# 部署指南：Vercel + Render 免费云平台

## 概述

将应用部署到免费云平台，实现永久稳定运行：
- **前端**：Vercel（免费，自动部署）
- **后端**：Render（免费，750小时/月）
- **数据库**：Supabase（已有，免费）
- **存储**：对象存储（已有，免费）

---

## 前置准备

你需要准备：
1. ✅ GitHub 账号（没有就去 https://github.com 注册）
2. ✅ Vercel 账号（用 GitHub 登录）
3. ✅ Render 账号（用 GitHub 登录）

---

## 第一步：将代码推送到 GitHub

### 1.1 创建 GitHub 仓库

1. 打开 https://github.com
2. 点击右上角 **+** → **New repository**
3. 填写：
   - Repository name: `health-app`
   - 选择 **Private**（私有仓库）
4. 点击 **Create repository**

### 1.2 初始化 Git 并推送代码

在沙箱终端执行以下命令：

```bash
cd /workspace/projects

# 初始化 Git（如果还没有）
git init

# 添加所有文件
git add .

# 提交
git commit -m "Initial commit"

# 添加远程仓库（替换成你的用户名）
git remote add origin https://github.com/你的用户名/health-app.git

# 推送
git branch -M main
git push -u origin main
```

---

## 第二步：部署后端到 Render

### 2.1 注册 Render

1. 打开 https://render.com
2. 点击 **Get Started** → 选择 **Sign up with GitHub**
3. 授权 GitHub 访问

### 2.2 创建 Web Service

1. 登录后，点击 **New** → **Web Service**
2. 选择你刚创建的 `health-app` 仓库
3. 填写配置：

| 配置项 | 值 |
|--------|---|
| **Name** | `health-app-backend` |
| **Region** | `Oregon (US West)` 或 `Singapore` |
| **Branch** | `main` |
| **Root Directory** | `server` |
| **Runtime** | `Node` |
| **Build Command** | `pnpm install` |
| **Start Command** | `pnpm start` |
| **Instance Type** | `Free` |

### 2.3 添加环境变量

点击 **Advanced** → **Add Environment Variable**，添加以下变量：

```
DATABASE_URL=你的Supabase数据库URL
SUPABASE_DB_URL=你的Supabase数据库URL
COZE_BUCKET_ENDPOINT_URL=你的对象存储地址
COZE_BUCKET_NAME=你的bucket名称
COZE_WORKLOAD_IDENTITY_CLIENT_ID=你的accessKeyId
COZE_WORKLOAD_IDENTITY_CLIENT_SECRET=你的secretAccessKey
JWT_SECRET=your-secret-key-change-this
ADMIN_KEY=88888888
```

### 2.4 部署

1. 点击 **Create Web Service**
2. 等待 3-5 分钟完成部署
3. 部署成功后会得到一个地址，如：`https://health-app-backend.onrender.com`

---

## 第三步：部署前端到 Vercel

### 3.1 注册 Vercel

1. 打开 https://vercel.com
2. 点击 **Sign Up** → 选择 **Continue with GitHub**
3. 授权 GitHub 访问

### 3.2 创建项目

1. 登录后，点击 **Add New** → **Project**
2. 选择 `health-app` 仓库
3. 填写配置：

| 配置项 | 值 |
|--------|---|
| **Framework Preset** | `Other` |
| **Root Directory** | `client` |
| **Build Command** | `npm run build` |
| **Output Directory** | `dist` |

### 3.3 添加环境变量

点击 **Environment Variables**，添加：

```
EXPO_PUBLIC_BACKEND_BASE_URL=https://health-app-backend.onrender.com
```

### 3.4 部署

1. 点击 **Deploy**
2. 等待 2-3 分钟完成部署
3. 部署成功后会得到一个地址，如：`https://health-app.vercel.app`

---

## 第四步：更新后端 CORS 配置

在 Render 的环境变量中添加：

```
ALLOWED_ORIGINS=https://health-app.vercel.app
```

然后重新部署后端。

---

## 完成后的地址

| 服务 | 地址 |
|------|------|
| **前端网页** | `https://health-app.vercel.app` |
| **后端 API** | `https://health-app-backend.onrender.com` |
| **APK 管理** | `https://health-app-backend.onrender.com/api/v1/admin/apk` |

---

## 注意事项

### Render 免费版限制
- 每月 750 小时（足够一个服务 24/7 运行）
- 首次访问可能需要 30 秒冷启动
- 15 分钟无请求会休眠

### 避免休眠的方法
1. 使用 UptimeRobot 定时 ping
2. 或者用 GitHub Actions（见下方）

### GitHub Actions 保活（可选）

在仓库创建 `.github/workflows/keepalive.yml`：

```yaml
name: Keep Alive
on:
  schedule:
    - cron: '*/10 * * * *'
  workflow_dispatch:

jobs:
  ping:
    runs-on: ubuntu-latest
    steps:
      - name: Ping Backend
        run: curl -s https://health-app-backend.onrender.com/api/v1/health
```

---

## 常见问题

### Q: 部署失败怎么办？
A: 查看 Render/Vercel 的日志，根据错误信息修复

### Q: 数据库连接失败？
A: 检查环境变量是否正确配置

### Q: 前端访问后端报错？
A: 检查 CORS 配置和后端地址是否正确

---

**现在告诉我你的 GitHub 用户名，我帮你生成具体的推送命令。**
