# 📱 APK 构建与更新指南

## 一、首次构建 APK（在本地电脑执行）

### 1. 安装 EAS CLI
```bash
npm install -g eas-cli
```

### 2. 登录 Expo 账号
```bash
eas login
# 如果没有账号，会提示注册（免费）
```

### 3. 构建 APK
```bash
cd client
eas build --platform android --profile preview
```

构建完成后，你会获得一个下载链接，可以直接下载 APK 分发给用户。

---

## 二、推送 OTA 更新（修改代码后）

### 方法一：在你本地电脑执行
```bash
cd client

# 推送更新到生产环境
eas update --branch production --message "修复登录问题"

# 或推送到预览环境
eas update --branch preview --message "测试新功能"
```

### 方法二：通过沙箱自动部署
如果平台支持自动部署，修改代码后会自动触发更新推送。

---

## 三、用户端更新流程

1. **自动检测**：用户打开 APP 时，自动检查是否有更新
2. **后台下载**：发现更新后静默下载
3. **提示重启**：下次打开 APP 时生效

---

## 四、当前配置信息

- **项目 ID**: 7618497784148443151
- **更新服务**: https://u.expo.dev/7618497784148443151
- **公网 API**: https://561b9af8-c1e5-426c-b873-60191e12cc56.dev.coze.site
- **管理员密码**: 88888888

---

## 五、常见问题

### Q: 修改代码后多久能生效？
A: 需要执行 `eas update` 后，用户下次打开 APP 时生效。

### Q: 能不能实时生效？
A: 不能，OTA 更新有延迟，用户需要重启 APP。

### Q: 原生代码修改怎么办？
A: 如果修改了原生配置（如权限、插件），需要重新构建 APK。

### Q: 公网 API 能长期使用吗？
A: 这是平台提供的公网域名，可以长期使用。

---

## 六、快速命令参考

```bash
# 构建 APK
eas build --platform android --profile preview

# 查看构建状态
eas build:list

# 推送更新
eas update --branch production --message "更新说明"

# 查看更新历史
eas update:list

# 查看项目信息
eas project:info
```
