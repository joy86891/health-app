#!/bin/bash
# ==================== Crontab 配置脚本 ====================
# 功能：设置定时任务，自动进行健康检查和日志轮转

SCRIPTS_DIR="/workspace/projects/.cozeproj/scripts"

# 创建临时 crontab 文件
TEMP_CRON=$(mktemp)

# 保留现有的非相关 crontab 条目
crontab -l 2>/dev/null | grep -v "watchdog.sh" | grep -v "logrotate.sh" > "$TEMP_CRON" 2>/dev/null || true

# 添加新的定时任务
echo "# 服务健康检查 - 每 5 分钟执行一次" >> "$TEMP_CRON"
echo "*/5 * * * * $SCRIPTS_DIR/watchdog.sh >> /workspace/projects/logs/cron_watchdog.log 2>&1" >> "$TEMP_CRON"
echo "" >> "$TEMP_CRON"
echo "# 日志轮转 - 每天凌晨 3 点执行" >> "$TEMP_CRON"
echo "0 3 * * * $SCRIPTS_DIR/logrotate.sh >> /workspace/projects/logs/cron_logrotate.log 2>&1" >> "$TEMP_CRON"

# 安装新的 crontab
crontab "$TEMP_CRON"
rm "$TEMP_CRON"

echo "Crontab 配置完成！"
echo ""
echo "当前定时任务："
crontab -l
