#!/bin/bash
# ==================== 日志轮转脚本 ====================
# 功能：定期清理和归档日志文件，防止磁盘空间不足
# 建议配置 crontab 每天凌晨 3 点执行一次

ROOT_DIR="/workspace/projects"
LOG_DIR="${COZE_LOG_DIR:-$ROOT_DIR/logs}"
MAX_LOG_SIZE="100M"  # 最大日志大小
MAX_LOG_FILES=30     # 最多保留日志文件数
MAX_LOG_AGE=7        # 最大日志天数

mkdir -p "$LOG_DIR"
ARCHIVE_DIR="$LOG_DIR/archive"
mkdir -p "$ARCHIVE_DIR"

log() {
  local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
  echo "[$timestamp] [LOGROTATE] $1"
}

# ==================== 日志轮转逻辑 ====================
log "开始日志轮转..."

# 获取当前日期
DATE_STAMP=$(date '+%Y%m%d')

# 遍历日志目录中的文件
for log_file in "$LOG_DIR"/*.log; do
  if [ -f "$log_file" ]; then
    file_name=$(basename "$log_file")
    file_size=$(du -b "$log_file" 2>/dev/null | cut -f1)
    
    # 如果文件大于 100MB，进行归档
    if [ "$file_size" -gt 104857600 ]; then
      log "归档大文件: $file_name (${file_size} bytes)"
      mv "$log_file" "$ARCHIVE_DIR/${file_name%.*}_${DATE_STAMP}.log"
      # 创建新的空日志文件
      touch "$log_file"
    fi
  fi
done

# 删除超过 7 天的归档日志
log "清理超过 $MAX_LOG_AGE 天的旧日志..."
find "$ARCHIVE_DIR" -name "*.log" -type f -mtime +$MAX_LOG_AGE -delete 2>/dev/null

# 如果归档文件超过 30 个，删除最旧的
archive_count=$(find "$ARCHIVE_DIR" -name "*.log" -type f | wc -l)
if [ "$archive_count" -gt "$MAX_LOG_FILES" ]; then
  log "归档文件数超过 $MAX_LOG_FILES，清理最旧的文件..."
  find "$ARCHIVE_DIR" -name "*.log" -type f -printf '%T@ %p\n' | sort -n | head -n -"$MAX_LOG_FILES" | cut -d' ' -f2- | xargs rm -f 2>/dev/null
fi

log "日志轮转完成"

# 显示当前日志目录状态
log "当前日志目录状态:"
log "  - 活动日志文件: $(find "$LOG_DIR" -maxdepth 1 -name "*.log" -type f | wc -l)"
log "  - 归档日志文件: $(find "$ARCHIVE_DIR" -name "*.log" -type f | wc -l)"
log "  - 总大小: $(du -sh "$LOG_DIR" 2>/dev/null | cut -f1)"
