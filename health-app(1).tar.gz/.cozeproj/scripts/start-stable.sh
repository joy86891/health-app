#!/bin/bash
# ==================== 稳定启动脚本 ====================
# 功能：以守护进程方式启动服务，确保长期稳定运行

ROOT_DIR="/workspace/projects"
LOG_DIR="${COZE_LOG_DIR:-$ROOT_DIR/logs}"
PID_DIR="$ROOT_DIR/.pids"
LOG_STARTUP_FILE="$LOG_DIR/startup.log"

mkdir -p "$LOG_DIR"
mkdir -p "$PID_DIR"

log() {
  local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
  echo "[$timestamp] [STARTUP] $1"
  echo "[$timestamp] [STARTUP] $1" >> "$LOG_STARTUP_FILE"
}

kill_by_pidfile() {
  local pidfile="$1"
  if [ -f "$pidfile" ]; then
    local pid=$(cat "$pidfile" 2>/dev/null)
    if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
      log "停止进程 PID: $pid"
      kill -TERM "$pid" 2>/dev/null || true
      sleep 2
      kill -9 "$pid" 2>/dev/null || true
    fi
    rm -f "$pidfile"
  fi
}

# ==================== 停止旧服务 ====================
log "停止旧服务..."

kill_by_pidfile "$PID_DIR/server.pid"
kill_by_pidfile "$PID_DIR/expo.pid"

# 额外清理可能残留的进程
pkill -f "tsx watch.*src/index" 2>/dev/null || true
pkill -f "expo start" 2>/dev/null || true

sleep 2

# ==================== 启动新服务 ====================
log "启动新服务..."

cd "$ROOT_DIR"

# 后端服务
log "启动后端服务..."
cd "$ROOT_DIR/server"
nohup bash -c 'NODE_ENV=development PORT=9091 npx tsx watch ./src/index.ts 2>&1' > "$LOG_DIR/server.log" 2>&1 &
SERVER_PID=$!
echo $SERVER_PID > "$PID_DIR/server.pid"
log "后端服务 PID: $SERVER_PID"

cd "$ROOT_DIR"

# 等待后端启动
sleep 5

# 前端服务
log "启动前端服务..."
cd "$ROOT_DIR/client"
nohup bash -c 'EXPO_NO_DOTENV=1 npx expo start --port 5000 2>&1' > "$LOG_DIR/expo.log" 2>&1 &
EXPO_PID=$!
echo $EXPO_PID > "$PID_DIR/expo.pid"
log "前端服务 PID: $EXPO_PID"

cd "$ROOT_DIR"

# ==================== 等待并验证 ====================
log "等待服务启动..."

sleep 30

# 检查服务状态
check_port() {
  nc -z -w 2 localhost "$1" >/dev/null 2>&1
}

if check_port 9091; then
  log "后端服务启动成功 (端口 9091)"
else
  log "错误：后端服务启动失败"
fi

if check_port 5000; then
  log "前端服务启动成功 (端口 5000)"
else
  log "错误：前端服务启动失败"
fi

log "启动完成！"
log "提示：建议配置 crontab 定期执行 watchdog.sh 进行健康检查"
