#!/bin/bash
# ==================== 服务守护脚本 ====================
# 功能：定期检查服务状态，自动重启异常停止的服务
# 建议配置 crontab 每 5 分钟执行一次

ROOT_DIR="/workspace/projects"
LOG_DIR="${COZE_LOG_DIR:-$ROOT_DIR/logs}"
LOG_WATCHDOG_FILE="$LOG_DIR/watchdog.log"
SERVER_PORT="9091"
EXPO_PORT="5000"

mkdir -p "$LOG_DIR"

log() {
  local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
  echo "[$timestamp] [WATCHDOG] $1"
  echo "[$timestamp] [WATCHDOG] $1" >> "$LOG_WATCHDOG_FILE"
}

check_port() {
  local port=$1
  nc -z -w 2 localhost "$port" >/dev/null 2>&1
  return $?
}

restart_services() {
  log "正在重启所有服务..."
  cd "$ROOT_DIR"
  
  # 杀死所有旧进程
  pkill -f "tsx watch" 2>/dev/null || true
  pkill -f "expo start" 2>/dev/null || true
  pkill -f "node.*server" 2>/dev/null || true
  
  sleep 2
  
  # 重新启动服务
  bash .cozeproj/scripts/dev_run.sh >> "$LOG_DIR/watchdog_run.log" 2>&1 &
  
  log "服务重启命令已执行"
}

# ==================== 主检查逻辑 ====================
log "开始健康检查..."

SERVER_OK=true
EXPO_OK=true

# 检查后端服务
if check_port "$SERVER_PORT"; then
  log "后端服务 (端口 $SERVER_PORT) 正常"
else
  log "警告：后端服务 (端口 $SERVER_PORT) 无响应"
  SERVER_OK=false
fi

# 检查前端服务
if check_port "$EXPO_PORT"; then
  log "前端服务 (端口 $EXPO_PORT) 正常"
else
  log "警告：前端服务 (端口 $EXPO_PORT) 无响应"
  EXPO_OK=false
fi

# 如果任一服务异常，执行重启
if [ "$SERVER_OK" = "false" ] || [ "$EXPO_OK" = "false" ]; then
  log "检测到服务异常，执行重启..."
  restart_services
  
  # 等待服务启动
  sleep 30
  
  # 再次检查
  if check_port "$SERVER_PORT" && check_port "$EXPO_PORT"; then
    log "服务重启成功"
  else
    log "错误：服务重启后仍异常，请人工介入"
  fi
else
  log "所有服务正常"
fi

log "健康检查完成"
