#!/bin/bash
# ==================== 持续健康检查脚本 ====================
# 功能：在后台持续监控服务状态，自动重启异常停止的服务
# 使用：nohup ./health-monitor.sh > /dev/null 2>&1 &

ROOT_DIR="/workspace/projects"
LOG_DIR="${COZE_LOG_DIR:-$ROOT_DIR/logs}"
LOG_MONITOR_FILE="$LOG_DIR/health-monitor.log"
SERVER_PORT="9091"
EXPO_PORT="5000"
CHECK_INTERVAL=300  # 每 5 分钟检查一次

mkdir -p "$LOG_DIR"

log() {
  local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
  echo "[$timestamp] [MONITOR] $1"
  echo "[$timestamp] [MONITOR] $1" >> "$LOG_MONITOR_FILE"
}

check_port() {
  local port=$1
  nc -z -w 2 localhost "$port" >/dev/null 2>&1
  return $?
}

restart_services() {
  log "正在重启所有服务..."
  cd "$ROOT_DIR"
  
  # 杀死所有旧进程
  pkill -f "tsx watch" 2>/dev/null || true
  pkill -f "expo start" 2>/dev/null || true
  pkill -f "node.*server" 2>/dev/null || true
  
  sleep 3
  
  # 重新启动服务
  bash .cozeproj/scripts/dev_run.sh >> "$LOG_DIR/health-monitor-run.log" 2>&1 &
  
  log "服务重启命令已执行，等待启动..."
  sleep 30
  
  # 再次检查
  if check_port "$SERVER_PORT" && check_port "$EXPO_PORT"; then
    log "服务重启成功"
  else
    log "错误：服务重启后仍异常，请人工介入"
  fi
}

log "健康监控启动，检查间隔：${CHECK_INTERVAL}秒"

# 主循环
while true; do
  SERVER_OK=true
  EXPO_OK=true
  
  # 检查后端服务
  if check_port "$SERVER_PORT"; then
    log "后端服务 (端口 $SERVER_PORT) 正常"
  else
    log "警告：后端服务 (端口 $SERVER_PORT) 无响应"
    SERVER_OK=false
  fi
  
  # 检查前端服务
  if check_port "$EXPO_PORT"; then
    log "前端服务 (端口 $EXPO_PORT) 正常"
  else
    log "警告：前端服务 (端口 $EXPO_PORT) 无响应"
    EXPO_OK=false
  fi
  
  # 如果任一服务异常，执行重启
  if [ "$SERVER_OK" = "false" ] || [ "$EXPO_OK" = "false" ]; then
    log "检测到服务异常，执行重启..."
    restart_services
  fi
  
  log "健康检查完成，下次检查在 ${CHECK_INTERVAL} 秒后"
  sleep "$CHECK_INTERVAL"
done
